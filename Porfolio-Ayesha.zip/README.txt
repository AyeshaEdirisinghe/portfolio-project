This website has been prepared for my portfolio. Namely Ayesha Edirisinghe designed this website.
Initially I used Bootstrap along with HTML, CSS, JavaScript to create this.
Through that I was able to create the website in a very beautiful way.
Here I initially included many features such as the companies I worked for, the evaluations they gave me,
the hours I worked, the number of projects.